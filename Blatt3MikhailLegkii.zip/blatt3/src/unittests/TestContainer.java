package unittests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import blatt2Containers.List;
import blatt2Containers.Vector;
import blatt3.DoubleLinkedList;
import interfaces.Container;


class TestContainer {
	Container container;
	Container container2;
	
	@BeforeEach
	void setUp() {
		container = new List();
//		container = new Vector();
//		container = new DoubleLinkedList();
		container2 = new List();
//		container2 = new Vector();
//		container2 = new DoubleLinkedList();
	}
	
	@AfterEach
	void tearDown() {
		
	}
	
	@Test
	void emptyTest() {
		assertEquals(container.isEmpty(), true, "Container should be empty");
		container.add(Integer.valueOf(1));
		assertEquals(container.isEmpty(), false, "Container should not be empty");
	}
	
	@Test
	void sizeTest() {
		assertEquals(container.size(), 0, "size should be 0");
		container.add("test1");
		container.add("test2");
		container.add("test3");
		assertEquals(container.size(), 3, "size should be 3");
	}
	
	@Test
	void addTest() {
		container.add(Integer.valueOf(1));
		container.add("testSTring1");
		container.add(Float.valueOf(1.1f));
		assertEquals(container.size(), 3, "size should be 3");
		assertEquals(container.add(null), false, "shouldnt be able to add a null");
	}
	
	@Test
	void removeTest() {
		container.add("test1");
		try {
			container.remove(null);
			fail("null was accepted for .remove()");
		}catch (NullPointerException e) {
			
		}
		
		container.remove("test1");
		assertEquals(container.size(), 0, "Container should be empty");
		assertEquals(container.remove("blabla"), false, "Removal should have failed, as Container is empty");
		
	}
	
	@Test
	void containsTest() {
		container.add("test1");
		try {
			container.contains(null);
			fail("null was accepted for .contains()");
		}catch (NullPointerException e) {
			
		}
		
		assertEquals(container.contains("test1"), true, "Container should contain the Object");
		
	}
	
	@Test
	void toArrayTest() {
		container.add("test1");
		container.add("test2");
		container.add("test3");
		Object[] arr = container.toArray();
		assertEquals(arr.length, container.size(), "sizes should be the same");
		for (int i = 0; i < arr.length; i++) {
			assertEquals(arr[i], container.get(i), "Array doesnt contain the same elements as container");
		}
		container.clear();
		arr = container.toArray();
		assertEquals(arr.length, container.size(), "sizes should be the same (empty)");
		for (int i = 0; i < arr.length; i++) {
			assertEquals(arr[i], container.get(i), "Array doesnt contain the same elements as container (empty)");
		}
	}
	
	@Test
	void clearTest() {
		container.add("test1");
		container.add("test2");
		container.add("test3");
		container.clear();
		assertEquals(container.size(), 0, "Container should be empty");
	}
	
	@Test
	void getTest() {
		try {
			container.get(0);
			fail("should have failed as container is empty");
		}catch (IndexOutOfBoundsException e) {
			
		}
		
		container.add("test1");
		container.add("test2");
		container.add("test3");
		
		try {
			container.get(-1);
			fail("should have failed, invalid index");
		}catch (IndexOutOfBoundsException e) {
			
		}
		
		try {
			container.get(container.size());
			fail("should have failed, invalid index");
		}catch (IndexOutOfBoundsException e) {
			
		}
		
		assertEquals(container.get(0), "test1", "gotten object is not matching");
	}
	
	@Test
	void equalsTest() {
		container.add("test1");
		container.add("test2");
		container.add("test3");
		
		container2.add("test1");
		container2.add("test2");
		container2.add("test3");
		
		assertEquals(container.equals(container2), true, "Containers should be equal");
	}
	
	@Test
	void toStringTest() {
		container.add("test1");
		assertEquals(container.toString(), "index: 0, Object: test1\n", "Built String was wrong");
	}
	
}
