package interfaces;

public interface Omnivore extends Carnivore, Herbivore{
	
}
