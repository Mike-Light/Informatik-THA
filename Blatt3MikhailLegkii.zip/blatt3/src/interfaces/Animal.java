package interfaces;

public interface Animal {
	public int weight();
	
	public boolean isAlive();
	
	public boolean isHungry();
	
}
