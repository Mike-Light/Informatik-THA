package interfaces;

public interface Carnivore extends Animal{
	public void eatMeat();
}
