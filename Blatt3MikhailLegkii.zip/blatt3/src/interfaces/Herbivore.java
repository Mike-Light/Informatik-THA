package interfaces;

public interface Herbivore extends Animal{
	public void eatPlant();
}
