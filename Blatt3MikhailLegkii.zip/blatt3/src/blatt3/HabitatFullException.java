package blatt3;

public class HabitatFullException extends Exception{

	HabitatFullException(){}
	
	HabitatFullException(String msg){
		super(msg);
	}
	
}
