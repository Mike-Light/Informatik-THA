package blatt3;

public class InvalidAnimalException extends Exception{
	
	InvalidAnimalException(){}
	
	InvalidAnimalException(String msg){
		super(msg);
	}

}
