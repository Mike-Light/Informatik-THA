package blatt3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;

import interfaces.Animal;
import interfaces.Carnivore;
import interfaces.Herbivore;
import interfaces.Omnivore;
import dummyImpls.Bunny;

public class ZooHabitat {

	private DoubleLinkedList animals = new DoubleLinkedList();
	private int maxCapacity;
	private int animalAmount;
	
	public ZooHabitat(int capacity) {
		maxCapacity = capacity;
	}
	
	public void addAnimal(Animal animal) throws InvalidAnimalException, HabitatFullException {
		
		if (animalAmount == maxCapacity) {
			throw (new HabitatFullException());
		}
		if  (animalAmount == 0) {
			animals.add(animal);
			animalAmount++;
		}else {
			if (animal.getClass().getInterfaces()[0] != animals.get(0).getClass().getInterfaces()[0]) {
				throw (new InvalidAnimalException());
			}
			
			animals.add(animal);
			animalAmount++;
			
		}
	}
	
	public int animals() {
		return animalAmount;
	}
	
	public int getCapacity() {
		return maxCapacity;
	}
	
}
