package blatt2Containers;
import blatt3.AbstractContainer;

public class Vector extends AbstractContainer {
	
	protected int size = 0;
	protected Object[] array = new Object[0];

	@Override
	public boolean add(Object o) {
		if (o != null) {
			Object[] arr = new Object[size+1];
			for (int i = 0; i < size; i++) {
				arr[i] = array[i];
			}
			arr[size] = o;
			array = arr;
			size++;
			if (array.length == size) {
				return true;
			}
		}
		
		return false;
	}

	@Override
	public Object get(int i) throws IndexOutOfBoundsException {
		if (i > -1 && i < size && !isEmpty()) {
			return array[i];
		}
		throw(new IndexOutOfBoundsException());
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean remove(Object o) throws NullPointerException {
		if (o == null) {
			throw(new NullPointerException());
		}
		if (!isEmpty() && contains(o)) { //Adding && contains(o) to the if causes removing to be much fatser
			int indexToRemove = -1;//    but subsequent adding and clearing becomes MUCH slower, WHY?
			
			for (int i = 0; i < size; i++) {
				if (array[i].equals(o)) {
					indexToRemove = i;
					break;
				}
			}
			
			if(indexToRemove != -1) {
				Object[] arr = new Object[size-1];
				int offset = 0;
				
				for (int i = 0; i < size - 1; i++) {
					if (i == indexToRemove) {
						offset = 1;
					}
					arr[i] = array[i + offset];
				}
				array = arr;
				size--;
				return true;
			}
		}
		return false;
	}
	
	public void clear() {
		this.array = new Object[0];
		this.size = 0;
	}
	
}
