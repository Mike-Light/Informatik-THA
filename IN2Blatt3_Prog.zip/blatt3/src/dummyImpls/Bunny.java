package dummyImpls;

import interfaces.Herbivore;

public class Bunny implements Herbivore{
	
	private int weight;
	private boolean isAlive;
	private boolean isHungry;
	
	public Bunny(int w){
		weight = w;
		isAlive = true;
		isHungry = true;
	}

	@Override
	public int weight() {
		return weight;
	}

	@Override
	public boolean isAlive() {
		return isAlive;
	}

	@Override
	public boolean isHungry() {
		return isHungry;
	}

	@Override
	public void eatPlant() {
		System.out.println("woooow weed i love to eat");
		
	}

}
