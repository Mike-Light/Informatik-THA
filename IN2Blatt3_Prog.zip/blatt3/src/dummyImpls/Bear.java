package dummyImpls;

import interfaces.Omnivore;

public class Bear implements Omnivore{
	
	private int weight;
	private boolean isAlive;
	private boolean isHungry;
	
	public Bear(int w){
		weight = w;
		isAlive = true;
		isHungry = true;
	}

	@Override
	public int weight() {
		return weight;
	}

	@Override
	public boolean isAlive() {
		return isAlive;
	}

	@Override
	public boolean isHungry() {
		return isHungry;
	}

	@Override
	public void eatPlant() {
		System.out.println("wooow such delish tofu");
		
	}
	
	@Override
	public void eatMeat() {
		System.out.println("hmmm yummy meat schmeat");
	}

}
