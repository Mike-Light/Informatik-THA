package unittests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import blatt3.HabitatFullException;
import blatt3.InvalidAnimalException;
import blatt3.ZooHabitat;
import dummyImpls.Bunny;
import dummyImpls.Shark;

class TestHabitat {

	ZooHabitat habitat;
	Bunny b = new Bunny(10);
	Shark s = new Shark(100);
	
	@BeforeEach
	void setUp() throws Exception {
		habitat = new ZooHabitat(3);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void addAnimalFullTest() throws InvalidAnimalException, HabitatFullException {
		
		habitat.addAnimal(b);
		habitat.addAnimal(b);
		habitat.addAnimal(b);
		
		try {
			habitat.addAnimal(b);
			fail("should not be able to add 4 bunnies, only 3");
		}catch (HabitatFullException e) {
			
		}
	}
	
	void addAnimalWrongTest() throws InvalidAnimalException, HabitatFullException {
		
		habitat.addAnimal(s);
		habitat.addAnimal(s);
		
		try {
			habitat.addAnimal(b);
			fail("you threw a bunny in a shark tank");
		}catch (InvalidAnimalException e) {
			
		}
		
	}
	
	@Test
	void animalsTest() throws InvalidAnimalException, HabitatFullException {
		
		habitat.addAnimal(b);
		habitat.addAnimal(b);
		
		assertEquals(habitat.animals(), 2, "wrong amount of animals in habitat");
	}
	
	@Test
	void capacityTest() {
		assertEquals(habitat.getCapacity(), 3, "should be 3, isn't");
	}

}
