package blatt2Containers;
import blatt3.AbstractContainer;

class listElement {
	listElement(Object o)
	{
		if (o != null) {
			this.part = o;
		}else {
			this.part = null;
		}
		
	}
	public listElement nextElement = null;
	public Object part = null;
}

public class List extends AbstractContainer{
	protected int length = 0;
	protected listElement first = null;
	
	@Override
	public boolean add(Object o) {
		if (o != null) {
			if(length > 0) {
				length++;
				listElement temp = new listElement(o);
				listElement current = first;
				while (current.nextElement != null) {
					current = current.nextElement;
				}
				current.nextElement = temp;
			}else {
				length++;
				first = new listElement(o);
			}
			return true;
		}
		return false;
	}
	
	public Object popBack() {
		listElement current = first;
		if (length == 0) {
			return null;
		}else if(length == 1) {
			first = null;
			length--;
			return current;
		}else {
			length--;
			return popBack(current);
		}
	}
	
	public Object popBack(listElement elem) {
		if (elem.nextElement.nextElement == null) {
			Object o = elem.nextElement;
			elem.nextElement = null;
			return o;
		}else {
			return popBack(elem.nextElement);
		}
	}
	
	public Object getFront() {
		return first.part;
	}
	
	@Override
	public Object get(int index) throws IndexOutOfBoundsException {
		if (index > length-1 || index < 0 || isEmpty()) {
			throw(new IndexOutOfBoundsException());
		}
		listElement current = new listElement(null);
		current.nextElement = first;
		for (int i = 0; i < length-(length-index-1); i++) {
			current = current.nextElement;
		}
		return current.part;
	}
	
	@Override
	public int size() {
		return length;
	}

	@Override
	public boolean remove(Object o) throws NullPointerException {
		if (o == null) {
			throw(new NullPointerException());
		}
		if (!isEmpty()) {
			if (getFront() == o) {
				first = first.nextElement;
				length--;
				return true;
			}
			
			listElement current = first;
			
			while (current.nextElement != null && current.nextElement.part != o) {
				current = current.nextElement;
			}
			
			if (current.nextElement == null) {
				return false;
			}
			current.nextElement = current.nextElement.nextElement;
			length--;
			return true;	
		}
		return false;
	}
	
	public void clear() {
		this.first = null;
		length = 0;
	}
	
}
